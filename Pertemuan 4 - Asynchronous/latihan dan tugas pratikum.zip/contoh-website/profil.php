<?php
    echo "ini halaman profil ". $_GET['name'];

?>