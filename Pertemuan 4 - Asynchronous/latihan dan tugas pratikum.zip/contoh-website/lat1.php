<?php
    echo "Selamat datang di php";
?>