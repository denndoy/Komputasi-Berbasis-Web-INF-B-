<?php
//GET dan POST

echo $_GET['name']
?>

<form action="getdanpost.php" method="get">
    <input type="text" name="name">
    <input type="password" name="password">
    <input type="submit" name="submit">
</form>
